package com.equilibrium.server_and_client.client.command;

import com.equilibrium.OnServerInitialize;
import com.equilibrium.entity.ITransformablePlayer;
import com.equilibrium.entity.path_finder.AStarCanGoTo;
import com.equilibrium.entity.path_finder.AStarCanGoToAndReturn;
import com.equilibrium.entity.path_finder.AStarSimplePathfinder;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

import java.util.List;


import static com.equilibrium.server_and_client.server.moonphase_tasks.MoonPhaseEvent.getMoonType;
import static com.equilibrium.server_and_client.server.event.UpdateArmorEvent.updatePlayerArmor;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;

public class ClientCommands {






    public static void registerClientAllCommands(CommandDispatcher<FabricClientCommandSource> dispatcher) {
        /*
         * 统一注册所有客户端命令
         */
        // 注册 moonType 命令
        dispatcher.register(ClientCommandManager.literal("moonType")
                .executes(context -> {
                    // 从客户端获取当前世界
                    var world = MinecraftClient.getInstance().world;

                    if (world == null) {
                        context.getSource().sendFeedback(Text.literal("无法获取当前世界。"));
                    } else {
                        // 调用你写好的 getMoonType 方法获取月相
                        String moon = getMoonType(world);
                        context.getSource().sendFeedback(Text.literal("当前月相是: " + moon));
                    }
                    return 1;
                })
        );

        // dispatcher.register(ClientCommandManager.literal("gettransformed")
        //         .executes(context -> {
        //             ClientPlayerEntity player = context.getSource().getPlayer();
                    
        //             boolean isTransformed = false;
        //             if (player instanceof ITransformablePlayer) {
        //                 isTransformed = ((ITransformablePlayer) player).isTransformed();
        //             }
                    
        //             String status = isTransformed ? "§a已蜕变" : "§c未蜕变";
        //             player.sendMessage(Text.of("§6=== 蜕变状态 ==="), false);
        //             player.sendMessage(Text.of("§7当前状态: " + status), false);
                    
        //             if (isTransformed) {
        //                 player.sendMessage(Text.of("§7最大生命值上限: §f80 点"), false);
        //                 player.sendMessage(Text.of("§7经验等级上限: §f200 级"), false);
        //             } else {
        //                 player.sendMessage(Text.of("§7最大生命值上限: §f20 点"), false);
        //                 player.sendMessage(Text.of("§7经验等级上限: §f50 级"), false);
        //             }
        //             return 1;
        //         })
        // );

        // dispatcher.register(ClientCommandManager.literal("transformed")
        //     .requires(source -> source.hasPermissionLevel(2))
        //     .then(ClientCommandManager.argument("value", BoolArgumentType.bool())
        //             .executes(context -> {
        //                 boolean value = BoolArgumentType.getBool(context, "value");
        //                 ClientPlayerEntity player = context.getSource().getPlayer();
                        
        //                 if (player instanceof ITransformablePlayer) {
        //                     ((ITransformablePlayer) player).setTransformed(value);
        //                     player.sendMessage(Text.of("§6蜕变状态已设置为: " + (value ? "§a已蜕变" : "§c未蜕变")), false);
        //                 } else {
        //                     player.sendMessage(Text.of("§c无法设置蜕变状态"), false);
        //                 }
        //                 return 1;
        //             })
        //     )
        // );

        dispatcher.register(
                ClientCommandManager.literal("fastFlySpeed")
                        .then(argument("speed", FloatArgumentType.floatArg(0.1F,0.5F))
                        .requires(source -> source.hasPermissionLevel(2))
                        .executes
                                (context -> {
                                    float speed = FloatArgumentType.getFloat(context, "speed");
                                    if (context.getSource().getEntity() instanceof ClientPlayerEntity clientPlayerEntity) {
                                        clientPlayerEntity.getAbilities().setFlySpeed(speed);
                                        clientPlayerEntity.sendMessage(Text.of("The Fly speed is now: "+speed));
                                    }
                                    else
                                        OnServerInitialize.LOGGER.error("This command \"fastFlySpeed\" can only be used by client player");
                                    return 1;
                                })

        ));




        // 注册 day 命令
        dispatcher.register(ClientCommandManager.literal("day")
                .executes(context -> {
                    // 从客户端获取当前世界
                    var world = MinecraftClient.getInstance().world;

                    if (world == null) {
                        context.getSource().sendFeedback(Text.literal("无法获取当前世界。"));
                    } else {
                        long time = world.getTimeOfDay();
                        int day = (int) (time / 24000L);
                        context.getSource().sendFeedback(Text.literal("It is day " + day));
                    }
                    return 1;
                })
        );
        // 注册 protection命令
        dispatcher.register(ClientCommandManager.literal("protection")
                .executes(context -> {
                    PlayerEntity player = context.getSource().getPlayer();
                    Text text = updatePlayerArmor(player);
                    player.sendMessage(text);

                    return 1;
                })
        );


        // 注册 tickSpeed 命令
        //需要用服务器的实例检测随机刻速度,而不是客户端的世界
//        dispatcher.register(ClientCommandManager.literal("randomTickSpeed")
//                .executes(context -> {
//
//                    int speed = ServerInfoRecorder.getServerInstance().getGameRules().getInt(GameRules.RANDOM_TICK_SPEED);
//
//                    context.getSource().getPlayer().sendMessage(Text.of("Random tick speed is"+speed));
//
//                    return 1;
//                })
//        );

        // 注册 A星算法 命令
        dispatcher.register(ClientCommandManager.literal("AStarFindPath")
                .then(argument("x1", IntegerArgumentType.integer())
                        .then(argument("y1", IntegerArgumentType.integer())
                                .then(argument("z1", IntegerArgumentType.integer())
                                        .then(argument("x2", IntegerArgumentType.integer())
                                                .then(argument("y2", IntegerArgumentType.integer())
                                                        .then(argument("z2", IntegerArgumentType.integer())
                .executes(context -> {
                    int x1 = IntegerArgumentType.getInteger(context, "x1");
                    int y1 = IntegerArgumentType.getInteger(context, "y1");
                    int z1 = IntegerArgumentType.getInteger(context, "z1");

                    int x2 = IntegerArgumentType.getInteger(context, "x2");
                    int y2 = IntegerArgumentType.getInteger(context, "y2");
                    int z2 = IntegerArgumentType.getInteger(context, "z2");
                    BlockPos start = new BlockPos(x1,y1,z1);
                    BlockPos goal = new BlockPos(x2,y2,z2);
                    List<BlockPos> path = AStarSimplePathfinder.findPath(context.getSource().getWorld(),start,goal);

                    if (path != null) {
                        // 找到可通行路径 => 屋顶到床连通 => 房屋不封闭
                        context.getSource().getPlayer().sendMessage(Text.of("找到路径"));
                    } else {
                        // 未找到路径 => 屋顶与床被阻隔 => 房屋真正封闭
                        context.getSource().getPlayer().sendMessage(Text.of("没有找到路径"));
                    }
                    return 1;
                }))))))));




        // 注册 A星算法 命令
        dispatcher.register(ClientCommandManager.literal("AStarFindPathCanGoTo")
                .then(argument("x1", IntegerArgumentType.integer())
                        .then(argument("y1", IntegerArgumentType.integer())
                                .then(argument("z1", IntegerArgumentType.integer())
                                        .then(argument("x2", IntegerArgumentType.integer())
                                                .then(argument("y2", IntegerArgumentType.integer())
                                                        .then(argument("z2", IntegerArgumentType.integer())
                                                                .executes(context -> {
                                                                    int x1 = IntegerArgumentType.getInteger(context, "x1");
                                                                    int y1 = IntegerArgumentType.getInteger(context, "y1");
                                                                    int z1 = IntegerArgumentType.getInteger(context, "z1");

                                                                    int x2 = IntegerArgumentType.getInteger(context, "x2");
                                                                    int y2 = IntegerArgumentType.getInteger(context, "y2");
                                                                    int z2 = IntegerArgumentType.getInteger(context, "z2");
                                                                    BlockPos start = new BlockPos(x1,y1,z1);
                                                                    BlockPos goal = new BlockPos(x2,y2,z2);
                                                                    boolean hasPath = AStarCanGoTo.hasPath(context.getSource().getWorld(),start,goal);

                                                                    if (hasPath) {
                                                                        // 找到可通行路径 => 屋顶到床连通 => 房屋不封闭
                                                                        context.getSource().getPlayer().sendMessage(Text.of("找到路径"));
                                                                    } else {
                                                                        // 未找到路径 => 屋顶与床被阻隔 => 房屋真正封闭
                                                                        context.getSource().getPlayer().sendMessage(Text.of("没有找到路径"));
                                                                    }
                                                                    return 1;
                                                                }))))))));
        dispatcher.register(ClientCommandManager.literal("AStarFindPathCanGoToAndReturn")
                .then(argument("x1", IntegerArgumentType.integer())
                        .then(argument("y1", IntegerArgumentType.integer())
                                .then(argument("z1", IntegerArgumentType.integer())
                                        .then(argument("x2", IntegerArgumentType.integer())
                                                .then(argument("y2", IntegerArgumentType.integer())
                                                        .then(argument("z2", IntegerArgumentType.integer())
                                                                .executes(context -> {
                                                                    int x1 = IntegerArgumentType.getInteger(context, "x1");
                                                                    int y1 = IntegerArgumentType.getInteger(context, "y1");
                                                                    int z1 = IntegerArgumentType.getInteger(context, "z1");

                                                                    int x2 = IntegerArgumentType.getInteger(context, "x2");
                                                                    int y2 = IntegerArgumentType.getInteger(context, "y2");
                                                                    int z2 = IntegerArgumentType.getInteger(context, "z2");
                                                                    BlockPos start = new BlockPos(x1,y1,z1);
                                                                    BlockPos goal = new BlockPos(x2,y2,z2);
                                                                    List<BlockPos> path = AStarCanGoToAndReturn.findSimplePath(context.getSource().getWorld(),start,goal);

                                                                    if (path!=null) {
                                                                        // 找到可通行路径 => 屋顶到床连通 => 房屋不封闭
                                                                        context.getSource().getPlayer().sendMessage(Text.of("找到路径"));
                                                                    } else {
                                                                        // 未找到路径 => 屋顶与床被阻隔 => 房屋真正封闭
                                                                        context.getSource().getPlayer().sendMessage(Text.of("没有找到路径"));
                                                                    }
                                                                    return 1;
                                                                }))))))));
    }


}





// 注册 locate 命令
//        dispatcher.register(ClientCommandManager.literal("locate")
//                .requires(source -> source.hasPermissionLevel(2))  // 设置权限
//                .then(ClientCommandManager.literal("structure")
//                        .then(ClientCommandManager.argument("structure", StringArgumentType.word())  // 接受结构名称
//                                .executes(context -> {
//                                    // 获取玩家输入的结构名称
//                                    String structure = StringArgumentType.getString(context, "structure");
//                                    // 这里你可以使用结构名称来处理命令逻辑
//                                    // 举个例子，打印结构名称
//                                    context.getSource().sendFeedback(Text.literal("Locating structure: " + structure));
//                                    return 1;
//                                })
//                        )
//                )
//        );






    // 继续注册更多客户端命令...


