package com.equilibrium.server_and_client.client.render.entity.renderer;

import com.equilibrium.entity.mob.DarkBoneLordEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.SkeletonEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

import static com.equilibrium.OnServerInitialize.MOD_ID;

public class DarkBoneLordRenderer extends ModSkeletonEntityRenderer<DarkBoneLordEntity> {
    private static final Identifier TEXTURE = Identifier.of(MOD_ID, "textures/entity/bone_lord.png");
    private static final Identifier TEXTURE_EYES = Identifier.of(MOD_ID, "textures/entity/bone_lord_glow.png");

    public DarkBoneLordRenderer(EntityRendererFactory.Context context) {
        super(context);
        this.addFeature(new EyesFeatureRenderer(this));
    }

    @Override
    public Identifier getTexture(DarkBoneLordEntity entity) {
        return TEXTURE;
    }

    static class EyesFeatureRenderer extends FeatureRenderer<DarkBoneLordEntity, SkeletonEntityModel<DarkBoneLordEntity>> {
        public EyesFeatureRenderer(FeatureRendererContext<DarkBoneLordEntity, SkeletonEntityModel<DarkBoneLordEntity>> context) {
            super(context);
        }

        @Override
        public void render(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, DarkBoneLordEntity entity, float limbAngle, float limbDistance, float tickDelta, float animationProgress, float headYaw, float headPitch) {
            VertexConsumer vertexConsumer = vertexConsumers.getBuffer(RenderLayer.getEyes(TEXTURE_EYES));
            SkeletonEntityModel<DarkBoneLordEntity> model = this.getContextModel();
            model.setAngles(entity, limbAngle, limbDistance, animationProgress, headYaw, headPitch);
            model.head.render(matrices, vertexConsumer, 15728640, OverlayTexture.DEFAULT_UV);
        }
    }
}