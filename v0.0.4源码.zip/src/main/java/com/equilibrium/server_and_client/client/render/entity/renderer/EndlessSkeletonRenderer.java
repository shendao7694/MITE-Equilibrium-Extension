package com.equilibrium.server_and_client.client.render.entity.renderer;

import com.equilibrium.entity.mob.EndlessSkeletonEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.SkeletonEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

import static com.equilibrium.OnServerInitialize.MOD_ID;

public class EndlessSkeletonRenderer extends ModSkeletonEntityRenderer<EndlessSkeletonEntity> {
    private static final Identifier TEXTURE = Identifier.of(MOD_ID, "textures/entity/bone_lord.png");
    private static final Identifier TEXTURE_EYES = Identifier.of(MOD_ID, "textures/entity/bone_lord_glow.png");

    public EndlessSkeletonRenderer(EntityRendererFactory.Context context) {
        super(context);
        this.addFeature(new EyesFeatureRenderer(this));
    }

    @Override
    public Identifier getTexture(EndlessSkeletonEntity entity) {
        return TEXTURE;
    }

    static class EyesFeatureRenderer extends FeatureRenderer<EndlessSkeletonEntity, SkeletonEntityModel<EndlessSkeletonEntity>> {
        public EyesFeatureRenderer(FeatureRendererContext<EndlessSkeletonEntity, SkeletonEntityModel<EndlessSkeletonEntity>> context) {
            super(context);
        }

        @Override
        public void render(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, EndlessSkeletonEntity entity, float limbAngle, float limbDistance, float tickDelta, float animationProgress, float headYaw, float headPitch) {
            VertexConsumer vertexConsumer = vertexConsumers.getBuffer(RenderLayer.getEyes(TEXTURE_EYES));
            SkeletonEntityModel<EndlessSkeletonEntity> model = this.getContextModel();
            model.setAngles(entity, limbAngle, limbDistance, animationProgress, headYaw, headPitch);
            model.head.render(matrices, vertexConsumer, 15728640, OverlayTexture.DEFAULT_UV);
        }
    }
}