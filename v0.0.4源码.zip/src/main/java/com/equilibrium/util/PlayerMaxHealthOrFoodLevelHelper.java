package com.equilibrium.util;

import com.equilibrium.entity.ITransformablePlayer;
import com.equilibrium.mixin.player.PlayerEntityMixin;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.MinecraftServer;

import java.util.ArrayList;
import java.util.Collections;

public class PlayerMaxHealthOrFoodLevelHelper {


    public static int getMaxHealthOrFoodLevel(PlayerEntity player) {
        boolean isTransformed = false;
        if (player instanceof ITransformablePlayer) {
            isTransformed = ((ITransformablePlayer) player).isTransformed();
        }
        
        if(isTransformed) {
            return player.experienceLevel >= 185 ? 80 : 6 + (int)(( player.experienceLevel/ 5) * 2);
        }else {
            return player.experienceLevel >= 35 ? 20 : 6 + (int)(( player.experienceLevel/ 5) * 2);
        }
    }

}
