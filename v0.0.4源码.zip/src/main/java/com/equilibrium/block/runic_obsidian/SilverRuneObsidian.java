package com.equilibrium.block.runic_obsidian;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.context.LootContextParameterSet;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.util.StringIdentifiable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class SilverRuneObsidian extends Block {
    public static final MapCodec<SilverRuneObsidian> CODEC = createCodec(SilverRuneObsidian::new);
    
    public enum Variant implements StringIdentifiable {
        ALPHA("alpha"),
        BETA("beta"),
        GAMMA("gamma");
        
        private final String name;
        
        Variant(String name) {
            this.name = name;
        }
        
        @Override
        public String asString() {
            return this.name;
        }
        
        public static Variant fromName(String name) {
            for (Variant variant : Variant.values()) {
                if (variant.name.equals(name)) {
                    return variant;
                }
            }
            return ALPHA;
        }
        
        public static Variant fromNbt(NbtCompound nbt) {
            if (nbt != null && nbt.contains("variant")) {
                return fromName(nbt.getString("variant"));
            }
            return ALPHA;
        }
        
        public void writeToNbt(NbtCompound nbt) {
            nbt.putString("variant", this.name);
        }
    }
    
    public static final EnumProperty<Variant> VARIANT = EnumProperty.of("variant", Variant.class);
    
    public SilverRuneObsidian(Settings settings) {
        super(settings);
        this.setDefaultState(this.stateManager.getDefaultState().with(VARIANT, Variant.ALPHA));
    }
    
    @Override
    protected MapCodec<SilverRuneObsidian> getCodec() {
        return CODEC;
    }
    
    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(VARIANT);
    }
    
    @Override
    public BlockState getPlacementState(ItemPlacementContext ctx) {
        ItemStack stack = ctx.getStack();
        Variant variant = getVariantFromStack(stack);
        return this.getDefaultState().with(VARIANT, variant);
    }
    
    @Override
    public void onPlaced(World world, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack itemStack) {
        super.onPlaced(world, pos, state, placer, itemStack);
        if (!world.isClient) {
            Variant variant = getVariantFromStack(itemStack);
            world.setBlockState(pos, state.with(VARIANT, variant), Block.NOTIFY_ALL);
        }
    }

    @Override
    protected List<ItemStack> getDroppedStacks(BlockState state, LootContextParameterSet.Builder builder) {
        Variant variant = state.get(VARIANT);
        
        ItemStack dropStack = new ItemStack(this);
        NbtCompound nbt = new NbtCompound();
        variant.writeToNbt(nbt);
        dropStack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        
        return List.of(dropStack);
    }
    
    @Override
    public float getHardness() {
        return 0.0f;
    }
    
    public static Variant getVariantFromStack(ItemStack stack) {
        NbtComponent nbtComponent = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (nbtComponent != null) {
            NbtCompound nbt = nbtComponent.copyNbt();
            if (nbt != null && nbt.contains("variant")) {
                return Variant.fromName(nbt.getString("variant"));
            }
        }
        return Variant.ALPHA;
    }
    
    public static ItemStack setVariantOnStack(ItemStack stack, Variant variant) {
        NbtCompound nbt = new NbtCompound();
        variant.writeToNbt(nbt);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        return stack;
    }
    
    public static ItemStack createStackWithVariant(Block block, Variant variant, int count) {
        ItemStack stack = new ItemStack(block, count);
        return setVariantOnStack(stack, variant);
    }
}