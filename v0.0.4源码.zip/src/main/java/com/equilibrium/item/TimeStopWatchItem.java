package com.equilibrium.item;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class TimeStopWatchItem extends Item {

    private static final int MAX_DURABILITY = 3;
    private static final int REQUIRED_LEVEL = 100;
    private static final int STOP_DURATION = 60;
    private static final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

    public TimeStopWatchItem(Settings settings) {
        super(settings.maxDamage(MAX_DURABILITY));
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);

        if (world.isClient) {
            return TypedActionResult.success(stack);
        }

        int damage = stack.getDamage();
        if (damage >= MAX_DURABILITY) {
            user.sendMessage(Text.of("§c怀表已损坏！"), true);
            return TypedActionResult.fail(stack);
        }

        if (user.experienceLevel < REQUIRED_LEVEL) {
            user.sendMessage(Text.of("§c需要 " + REQUIRED_LEVEL + " 级经验才能使用时停怀表！"), true);
            return TypedActionResult.fail(stack);
        }

        if (world.getTickManager().isFrozen()) {
            user.sendMessage(Text.of("§c时间已经停止！"), true);
            return TypedActionResult.fail(stack);
        }

        user.addExperienceLevels(-REQUIRED_LEVEL);
        stack.setDamage(damage + 1);

        world.getTickManager().setFrozen(true);

        AtomicInteger remainingSeconds = new AtomicInteger(STOP_DURATION);

        scheduler.scheduleAtFixedRate(() -> {
            int remaining = remainingSeconds.decrementAndGet();
            if (remaining > 0 && world.getServer() != null) {
                world.getServer().getPlayerManager().getPlayerList().forEach(player -> {
                    player.sendMessage(Text.of("§e时停剩余: " + remaining + " 秒"), true);
                });
            }
        }, 1, 1, TimeUnit.SECONDS);

        scheduler.schedule(() -> {
            world.getTickManager().setFrozen(false);
            remainingSeconds.set(0);
            if (world.getServer() != null) {
                world.getServer().getPlayerManager().getPlayerList().forEach(player -> {
                    player.sendMessage(Text.of("§6时间恢复流动！"), false);
                });
            }
        }, STOP_DURATION, TimeUnit.SECONDS);

        world.playSound(null, user.getBlockPos(), SoundEvents.BLOCK_BEACON_POWER_SELECT, SoundCategory.PLAYERS, 1.0F, 0.5F);
        world.playSound(null, user.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 1.0F, 0.5F);

        user.sendMessage(Text.of("§6时间已停止！持续 60 秒！"), false);

        if (stack.getDamage() >= MAX_DURABILITY) {
            user.sendMessage(Text.of("§c怀表已破碎！"), false);
        }

        return TypedActionResult.success(stack);
    }

    @Override
    public boolean isItemBarVisible(ItemStack stack) {
        return true;
    }

    @Override
    public int getItemBarStep(ItemStack stack) {
        return Math.round((float) (MAX_DURABILITY - stack.getDamage()) / MAX_DURABILITY * 13);
    }

    @Override
    public int getItemBarColor(ItemStack stack) {
        return 0x00AA00;
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        super.appendTooltip(stack, context, tooltip, type);
        tooltip.add(Text.literal("§7右键使用，停止时间 60 秒"));
    }
}