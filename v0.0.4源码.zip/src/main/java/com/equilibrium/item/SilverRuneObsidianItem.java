package com.equilibrium.item;

import com.equilibrium.block.runic_obsidian.SilverRuneObsidian;
import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

public class SilverRuneObsidianItem extends BlockItem {
    
    public SilverRuneObsidianItem(Block block, Settings settings) {
        super(block, settings);
    }
    
    @Override
    public Text getName(ItemStack stack) {
        Block block = this.getBlock();
        if (block instanceof SilverRuneObsidian) {
            SilverRuneObsidian.Variant variant = SilverRuneObsidian.getVariantFromStack(stack);
            
            return switch (variant) {
                case ALPHA -> Text.translatable("block.miteequilibrium.silver_rune_obsidian.alpha")
                    .formatted(Formatting.AQUA);
                case BETA -> Text.translatable("block.miteequilibrium.silver_rune_obsidian.beta")
                    .formatted(Formatting.GOLD);
                case GAMMA -> Text.translatable("block.miteequilibrium.silver_rune_obsidian.gamma")
                    .formatted(Formatting.LIGHT_PURPLE);
            };
        }
        return super.getName(stack);
    }
    
    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        super.appendTooltip(stack, context, tooltip, type);
        
        Block block = this.getBlock();
        if (block instanceof SilverRuneObsidian) {
            SilverRuneObsidian.Variant variant = SilverRuneObsidian.getVariantFromStack(stack);
            String variantName = switch (variant) {
                case ALPHA -> "Alpha (α)";
                case BETA -> "Beta (β)";
                case GAMMA -> "Gamma (γ)";
            };
            tooltip.add(Text.literal("§7银符文黑曜石: §f" + variantName));
        }
    }
}