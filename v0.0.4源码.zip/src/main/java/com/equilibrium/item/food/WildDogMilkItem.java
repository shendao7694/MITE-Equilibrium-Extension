package com.equilibrium.item.food;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

public class WildDogMilkItem extends Item {

    public WildDogMilkItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);

        if (world.isClient) {
            return TypedActionResult.success(stack);
        }

        user.clearStatusEffects();

        int duration = 600;
        int amplifier = 9;

        user.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, duration, amplifier, false, false, true));
        user.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, duration, amplifier, false, false, true));
        user.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, duration, amplifier, false, false, true));
        user.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, duration, amplifier, false, false, true));
        user.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, duration, amplifier, false, false, true));
        user.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, duration, amplifier, false, false, true));

        stack.decrement(1);

        user.sendMessage(Text.of("§6你喝下了野生狗奶！"), true);

        return TypedActionResult.success(stack);
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        super.appendTooltip(stack, context, tooltip, type);
        tooltip.add(Text.literal("§7生命畏惧时间，而时间畏惧野生狗奶！"));

    }
}