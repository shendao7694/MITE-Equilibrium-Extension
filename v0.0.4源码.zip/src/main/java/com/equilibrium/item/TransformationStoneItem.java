// 文件: com/equilibrium/item/TransformationStoneItem.java
package com.equilibrium.item;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

import com.equilibrium.entity.ITransformablePlayer;

public class TransformationStoneItem extends Item {

    public TransformationStoneItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        
        if (world.isClient) {
            return TypedActionResult.success(stack);
        }

        if (user instanceof ITransformablePlayer) {
            if (((ITransformablePlayer) user).isTransformed()) {
                user.sendMessage(Text.of("§c你已经完成蜕变，无法再次使用！"), true);
                return TypedActionResult.fail(stack);
            }
        } else {
            user.sendMessage(Text.of("§c无法检测蜕变状态！"), true);
            return TypedActionResult.fail(stack);
        }

        if (user.experienceLevel < 30) {
            user.sendMessage(Text.of("§c需要至少 30 级才能使用蜕变石！"), true);
            return TypedActionResult.fail(stack);
        }

        if (!user.getAbilities().creativeMode) {
            stack.decrement(1);
        }

        ((ITransformablePlayer) user).setTransformed(true);

        world.playSound(null, user.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 1.0F, 1.0F);
        world.playSound(null, user.getBlockPos(), SoundEvents.BLOCK_BEACON_POWER_SELECT, SoundCategory.PLAYERS, 1.0F, 0.5F);

        user.sendMessage(Text.of("§6蜕变成功！你已获得 §l蜕变 §6状态！"), false);
        user.sendMessage(Text.of("§7你突破了等级限制，最大生命值上限提升至 80 点！"), false);
        
        return TypedActionResult.success(stack);
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        super.appendTooltip(stack, context, tooltip, type);
        tooltip.add(Text.literal("§7右键使用，消耗此物品完成蜕变"));
        tooltip.add(Text.literal("§7蜕变后将突破等级限制"));
        tooltip.add(Text.literal("§c注意：蜕变是不可逆的！"));
        tooltip.add(Text.literal("§e需求：等级 ≥ 30 级"));
    }
}