package com.equilibrium.item.tools_attribute.infinity;

import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MiningToolItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.List;

public class InfinityPickaxe extends MiningToolItem {
    
    public InfinityPickaxe(ToolMaterial toolMaterial, Settings settings) {
        super(toolMaterial, BlockTags.PICKAXE_MINEABLE, settings);
    }
    
    @Override
    public float getMiningSpeed(ItemStack stack, BlockState state) {
        return 999999.0f;
    }
    
    @Override
    public boolean canMine(BlockState state, World world, BlockPos pos, PlayerEntity miner) {
        return true;
    }

    @Override
    public boolean isCorrectForDrops(ItemStack stack, BlockState state) {
        return true;
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        super.appendTooltip(stack, context, tooltip, type);
    }
}