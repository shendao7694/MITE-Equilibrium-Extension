package com.equilibrium.item;

import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

import static com.equilibrium.OnServerInitialize.MOD_ID;

public class EssenceItems {

    // ========== 其他精华 ==========
    public static final Item ESSENCE_WORLD = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_ANVIL = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_DRAGON = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_EXP = new Item(new Item.Settings().maxCount(64));

    // ========== 维度精华 ==========
    public static final Item ESSENCE_OVERWORLD = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_NETHER = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_UNDERWORLD = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_THE_END = new Item(new Item.Settings().maxCount(64));

    // ========== 主世界生物精华 ==========
    public static final Item ESSENCE_ZOMBIE = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_SKELETON = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_CREEPER = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_SPIDER = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_PIG = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_SHEEP = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_COW = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_GUARDIAN = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_PILLAGER = new Item(new Item.Settings().maxCount(64));

    // ========== 地下世界生物精华 ==========
    public static final Item ESSENCE_LONGDEAD = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_WIGHT = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_GHOUL = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_SHADOW = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_INVISIBLE_STALKER = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_PUDDING = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_REVENANT = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_STONE_ELEMENTAL = new Item(new Item.Settings().maxCount(64));

    // ========== 下界生物精华 ==========
    public static final Item ESSENCE_PIGLIN = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_MAGMA_CUBE = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_PIGLIN_BRUTE = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_ZOMBIFIED_PIGLIN = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_WITHER_SKELETON = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_GHAST = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_BLAZE = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_NETHERRACK_ELEMENTAL = new Item(new Item.Settings().maxCount(64));

    // ========== 末地生物精华 ==========
    public static final Item ESSENCE_ENDERMAN = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_SHULKER = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_END_ROCK_ELEMENTAL = new Item(new Item.Settings().maxCount(64));
    public static final Item ESSENCE_OBSIDIAN_ELEMENTAL = new Item(new Item.Settings().maxCount(64));

    public static void registerEssenceItems() {
        // ===== 其他精华 =====
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_world"), ESSENCE_WORLD);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_anvil"), ESSENCE_ANVIL);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_dragon"), ESSENCE_DRAGON);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_exp"), ESSENCE_EXP);

        // ===== 维度精华 =====
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_overworld"), ESSENCE_OVERWORLD);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_nether"), ESSENCE_NETHER);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_underworld"), ESSENCE_UNDERWORLD);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_the_end"), ESSENCE_THE_END);

        // ===== 主世界生物精华 =====
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_zombie"), ESSENCE_ZOMBIE);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_skeleton"), ESSENCE_SKELETON);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_creeper"), ESSENCE_CREEPER);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_spider"), ESSENCE_SPIDER);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_pig"), ESSENCE_PIG);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_sheep"), ESSENCE_SHEEP);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_cow"), ESSENCE_COW);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_guardian"), ESSENCE_GUARDIAN);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_pillager"), ESSENCE_PILLAGER);

        // ===== 地下世界生物精华 =====
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_longdead"), ESSENCE_LONGDEAD);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_wight"), ESSENCE_WIGHT);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_ghoul"), ESSENCE_GHOUL);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_shadow"), ESSENCE_SHADOW);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_invisible_stalker"), ESSENCE_INVISIBLE_STALKER);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_pudding"), ESSENCE_PUDDING);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_revenant"), ESSENCE_REVENANT);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_stone_elemental"), ESSENCE_STONE_ELEMENTAL);

        // ===== 下界生物精华 =====
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_piglin"), ESSENCE_PIGLIN);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_magma_cube"), ESSENCE_MAGMA_CUBE);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_piglin_brute"), ESSENCE_PIGLIN_BRUTE);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_zombified_piglin"), ESSENCE_ZOMBIFIED_PIGLIN);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_wither_skeleton"), ESSENCE_WITHER_SKELETON);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_ghast"), ESSENCE_GHAST);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_blaze"), ESSENCE_BLAZE);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_netherrack_elemental"), ESSENCE_NETHERRACK_ELEMENTAL);

        // ===== 末地生物精华 =====
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_enderman"), ESSENCE_ENDERMAN);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_shulker"), ESSENCE_SHULKER);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_end_rock_elemental"), ESSENCE_END_ROCK_ELEMENTAL);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "essence_obsidian_elemental"), ESSENCE_OBSIDIAN_ELEMENTAL);
    }
}