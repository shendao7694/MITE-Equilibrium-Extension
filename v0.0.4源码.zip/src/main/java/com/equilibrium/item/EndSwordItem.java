package com.equilibrium.item;

import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.List;

import static com.equilibrium.OnServerInitialize.MOD_ID;

public class EndSwordItem extends SwordItem {

    private static final int COOLDOWN_TICKS = 20;

    public EndSwordItem(ToolMaterial material, Settings settings) {
        super(material, settings);
    }

    public static AttributeModifiersComponent createEndSwordAttributes(ToolMaterial material) {
        return AttributeModifiersComponent.builder()
                .add(
                        EntityAttributes.GENERIC_ATTACK_DAMAGE,
                        new EntityAttributeModifier(
                                BASE_ATTACK_DAMAGE_MODIFIER_ID,
                                99999.0,
                                EntityAttributeModifier.Operation.ADD_VALUE
                        ),
                        AttributeModifierSlot.MAINHAND
                )
                .add(
                        EntityAttributes.GENERIC_ATTACK_SPEED,
                        new EntityAttributeModifier(
                                BASE_ATTACK_SPEED_MODIFIER_ID,
                                9999.0,
                                EntityAttributeModifier.Operation.ADD_VALUE
                        ),
                        AttributeModifierSlot.MAINHAND
                )
                .add(
                        EntityAttributes.PLAYER_ENTITY_INTERACTION_RANGE,
                        new EntityAttributeModifier(
                                Identifier.of(MOD_ID, "end_sword_reach"),
                                9999.0,
                                EntityAttributeModifier.Operation.ADD_VALUE
                        ),
                        AttributeModifierSlot.MAINHAND
                )
                .build();
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);

        if (world.isClient) {
            return TypedActionResult.success(stack);
        }

        if (user.getItemCooldownManager().isCoolingDown(stack.getItem())) {
            return TypedActionResult.fail(stack);
        }

        ServerWorld serverWorld = (ServerWorld) world;
        Vec3d center = user.getPos();

        spawnRingParticles(serverWorld, center);

        world.playSound(null, user.getBlockPos(), SoundEvents.ENTITY_ENDER_DRAGON_GROWL, SoundCategory.PLAYERS, 2.0F, 0.5F);

        Box killBox = new Box(center.add(-10, -10, -10), center.add(10, 10, 10));
        List<Entity> entities = serverWorld.getOtherEntities(user, killBox);

        for (Entity entity : entities) {
            if (entity instanceof LivingEntity living && !(entity instanceof PlayerEntity)) {
                living.kill();
            }
        }

        user.getItemCooldownManager().set(stack.getItem(), COOLDOWN_TICKS);

        return TypedActionResult.success(stack);
    }

    private void spawnRingParticles(ServerWorld world, Vec3d center) {
        int particles = 64;
        double radius = 10.0;

        for (int i = 0; i < particles; i++) {
            double angle = 2 * Math.PI * i / particles;
            double x = center.x + Math.cos(angle) * radius;
            double z = center.z + Math.sin(angle) * radius;

            for (double y = -1; y <= 1; y += 0.5) {
                world.spawnParticles(
                        ParticleTypes.SOUL_FIRE_FLAME,
                        x, center.y + y, z,
                        1, 0, 0, 0, 0.01
                );
                world.spawnParticles(
                        ParticleTypes.END_ROD,
                        x, center.y + y, z,
                        1, 0, 0, 0, 0.01
                );
            }
        }

        world.spawnParticles(
                ParticleTypes.EXPLOSION_EMITTER,
                center.x, center.y, center.z,
                3, 1, 1, 1, 0
        );
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        super.appendTooltip(stack, context, tooltip, type);
    }
}