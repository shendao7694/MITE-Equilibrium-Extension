package com.equilibrium.item;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

public class FlightRingItem extends Item {

    public FlightRingItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);

        if (!world.isClient) {
            if (user.getAbilities().allowFlying) {
                user.getAbilities().allowFlying = false;
                user.getAbilities().flying = false;
                user.sendMessage(Text.translatable("item.miteequilibrium.flight_ring.disabled").formatted(Formatting.RED), true);
            } else {
                user.getAbilities().allowFlying = true;
                user.sendMessage(Text.translatable("item.miteequilibrium.flight_ring.enabled").formatted(Formatting.GREEN), true);
            }
            user.sendAbilitiesUpdate();
        }
        user.swingHand(hand);

        return TypedActionResult.success(stack, world.isClient);
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        super.appendTooltip(stack, context, tooltip, type);
        tooltip.add(Text.translatable("item.miteequilibrium.flight_ring.tooltip").formatted(Formatting.GRAY));
    }
}