package com.equilibrium.item;


import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

import static com.equilibrium.OnServerInitialize.MOD_ID;

public class Metal {

    //以下开始添加物品:
    public static final Item adamantium= new Item(new Item.Settings().maxCount(16));
    public static final Item ancient_metal = new Item(new Item.Settings().maxCount(16));
    public static final Item copper = new Item(new Item.Settings().maxCount(16));
    public static final Item gold = new Item(new Item.Settings().maxCount(16));
    public static final Item mithril = new Item(new Item.Settings().maxCount(16));
    public static final Item silver = new Item(new Item.Settings().maxCount(16));

    //maxCount = 32
    public static final Item adamantium_nugget= new Item(new Item.Settings().maxCount(64));
    public static final Item ancient_metal_nugget= new Item(new Item.Settings().maxCount(64));
    public static final Item copper_nugget = new Item(new Item.Settings().maxCount(64));
    public static final Item gold_nugget = new Item(new Item.Settings().maxCount(64));
    public static final Item mithril_nugget = new Item(new Item.Settings().maxCount(64));
    public static final Item silver_nugget = new Item(new Item.Settings().maxCount(64));


    public static final Item FLINT = new Item(new Item.Settings().maxCount(64));

    //maxCount = 16
    public static final Item ADAMANTIUM_RAW= new Item(new Item.Settings().maxCount(32));
    public static final Item MITHRIL_RAW = new Item(new Item.Settings().maxCount(32));
    public static final Item SILVER_RAW = new Item(new Item.Settings().maxCount(32));


    public static final Item vibranium = new Item(new Item.Settings().maxCount(16));
    public static final Item vibranium_nugget = new Item(new Item.Settings().maxCount(64));

    public static final Item strange_material = new Item(new Item.Settings().maxCount(16));

    public static final Item infinity_singularity_diamond = new Item(new Item.Settings().maxCount(16));
    public static final Item infinity_singularity_iron = new Item(new Item.Settings().maxCount(16));
    public static final Item infinity_singularity_mineral = new Item(new Item.Settings().maxCount(16));
    public static final Item infinity_singularity_mithril = new Item(new Item.Settings().maxCount(16));
    public static final Item infinity_singularity_silver = new Item(new Item.Settings().maxCount(16));

    public static final Item infinity_ingot = new Item(new Item.Settings().maxCount(16));

    public static final Item FLIGHT_RING = new FlightRingItem(new Item.Settings().maxCount(1));

    public static final Item TRANSFORMATION_STONE = new TransformationStoneItem(
        new Item.Settings().maxCount(1)
    );
    
    public static final Item DARK_BONE_LORD_ESSENCE = new Item(new Item.Settings().maxCount(64));
    public static final Item END_MATTER = new Item(new Item.Settings().maxCount(64));

    public static final Item TIME_STOP_WATCH = new TimeStopWatchItem(new Item.Settings().maxCount(1));
    public static final Item END_INGOT = new Item(new Item.Settings().maxCount(16));

    public static void registerModItemIngots() {
        EssenceItems.registerEssenceItems();
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "end_ingot"), END_INGOT);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "flight_ring"), FLIGHT_RING);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "transformation_stone"), TRANSFORMATION_STONE);
        
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "infinity_singularity_diamond"), infinity_singularity_diamond);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "infinity_singularity_iron"), infinity_singularity_iron);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "infinity_singularity_mineral"), infinity_singularity_mineral);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "infinity_singularity_mithril"), infinity_singularity_mithril);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "infinity_singularity_silver"), infinity_singularity_silver);

        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "infinity_ingot"), infinity_ingot);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID,"adamantium"), adamantium);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID,"ancient_metal"), ancient_metal);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID,"copper"), copper);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID,"gold"), gold);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID,"mithril"), mithril);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID,"silver"), silver);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "vibranium"), vibranium);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "strange_material"), strange_material);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "time_stop_watch"), TIME_STOP_WATCH);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID,"flint"), FLINT);

        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "dark_bone_lord_essence"), DARK_BONE_LORD_ESSENCE);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "end_matter"), END_MATTER);
    }
    public static void registerModItemNuggets(){
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID,"adamantium_nugget"), adamantium_nugget);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID,"ancient_metal_nugget"), ancient_metal_nugget);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID,"copper_nugget"), copper_nugget);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID,"gold_nugget"), gold_nugget);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID,"mithril_nugget"), mithril_nugget);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID,"silver_nugget"), silver_nugget);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "vibranium_nugget"), vibranium_nugget);

    }
    public static void registerModItemRaw(){
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID,"adamantium_raw"), ADAMANTIUM_RAW);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID,"mithril_raw"), MITHRIL_RAW);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID,"silver_raw"), SILVER_RAW);
        
    }




}
