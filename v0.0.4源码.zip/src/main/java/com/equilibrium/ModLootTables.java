package com.equilibrium;

import com.equilibrium.item.EssenceItems;
import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.minecraft.item.Item;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.condition.RandomChanceLootCondition;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.function.SetCountLootFunction;
import net.minecraft.loot.provider.number.ConstantLootNumberProvider;
import net.minecraft.loot.provider.number.UniformLootNumberProvider;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;

import java.util.Map;

public class ModLootTables {

    // 生物RegistryKey -> 精华物品
    private static final Map<RegistryKey<LootTable>, Item> ENTITY_LOOT = Map.ofEntries(
        // ===== 主世界 =====
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("minecraft", "entities/zombie")), EssenceItems.ESSENCE_ZOMBIE),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("minecraft", "entities/skeleton")), EssenceItems.ESSENCE_SKELETON),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("minecraft", "entities/creeper")), EssenceItems.ESSENCE_CREEPER),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("minecraft", "entities/spider")), EssenceItems.ESSENCE_SPIDER),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("minecraft", "entities/pig")), EssenceItems.ESSENCE_PIG),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("minecraft", "entities/sheep")), EssenceItems.ESSENCE_SHEEP),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("minecraft", "entities/cow")), EssenceItems.ESSENCE_COW),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("minecraft", "entities/guardian")), EssenceItems.ESSENCE_GUARDIAN),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("minecraft", "entities/pillager")), EssenceItems.ESSENCE_PILLAGER),
        
        // ===== 地下世界 =====
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("miteequilibrium", "entitiy/longdead")), EssenceItems.ESSENCE_LONGDEAD),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("miteequilibrium", "entitiy/wight")), EssenceItems.ESSENCE_WIGHT),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("miteequilibrium", "entitiy/ghoul")), EssenceItems.ESSENCE_GHOUL),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("miteequilibrium", "entitiy/shadow")), EssenceItems.ESSENCE_SHADOW),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("miteequilibrium", "entitiy/invisible_stalker")), EssenceItems.ESSENCE_INVISIBLE_STALKER),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("miteequilibrium", "entitiy/pudding")), EssenceItems.ESSENCE_PUDDING),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("miteequilibrium", "entitiy/revenant")), EssenceItems.ESSENCE_REVENANT),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("miteequilibrium", "entitiy/stone_elemental")), EssenceItems.ESSENCE_STONE_ELEMENTAL),
        
        // ===== 下界 =====
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("minecraft", "entities/piglin")), EssenceItems.ESSENCE_PIGLIN),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("minecraft", "entities/magma_cube")), EssenceItems.ESSENCE_MAGMA_CUBE),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("minecraft", "entities/piglin_brute")), EssenceItems.ESSENCE_PIGLIN_BRUTE),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("minecraft", "entities/zombified_piglin")), EssenceItems.ESSENCE_ZOMBIFIED_PIGLIN),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("minecraft", "entities/wither_skeleton")), EssenceItems.ESSENCE_WITHER_SKELETON),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("minecraft", "entities/ghast")), EssenceItems.ESSENCE_GHAST),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("minecraft", "entities/blaze")), EssenceItems.ESSENCE_BLAZE),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("miteequilibrium", "entitiy/netherrack_elemental")), EssenceItems.ESSENCE_NETHERRACK_ELEMENTAL),
        
        // ===== 末地 =====
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("minecraft", "entities/enderman")), EssenceItems.ESSENCE_ENDERMAN),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("minecraft", "entities/shulker")), EssenceItems.ESSENCE_SHULKER),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("miteequilibrium", "entitiy/end_rock_elemental")), EssenceItems.ESSENCE_END_ROCK_ELEMENTAL),
        Map.entry(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of("miteequilibrium", "entitiy/obsidian_elemental")), EssenceItems.ESSENCE_OBSIDIAN_ELEMENTAL)
    );

    public static void register() {
        LootTableEvents.MODIFY.register((key, tableBuilder, source) -> {
            Item essenceItem = ENTITY_LOOT.get(key);
            if (essenceItem != null) {
                LootPool.Builder poolBuilder = LootPool.builder()
                    .rolls(ConstantLootNumberProvider.create(1))
                    .with(ItemEntry.builder(essenceItem)
                        .weight(1)
                        .apply(SetCountLootFunction.builder(UniformLootNumberProvider.create(1.0f, 1.0f)))
                    )
                    .conditionally(RandomChanceLootCondition.builder(0.01f));

                tableBuilder.pool(poolBuilder.build());
            }
        });
    }
}