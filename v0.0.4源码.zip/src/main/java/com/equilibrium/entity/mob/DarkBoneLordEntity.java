package com.equilibrium.entity.mob;

import com.equilibrium.OnServerInitialize;
import com.equilibrium.item.Armors;
import com.equilibrium.item.Tools;
import net.minecraft.entity.*;
import net.minecraft.entity.ai.TargetPredicate;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.passive.WolfEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Unique;
import net.minecraft.loot.LootTable;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import com.equilibrium.item.Metal;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.function.Predicate;

import static com.equilibrium.entity.ModEntities.BONE_LORD;
import static com.equilibrium.entity.ModEntities.LONG_DEAD;
import static com.equilibrium.util.XpHashMap.getXpForLevel;
import static net.minecraft.entity.effect.StatusEffects.SLOWNESS;
import static com.equilibrium.OnServerInitialize.MOD_ID;

public class DarkBoneLordEntity extends LongDeadEntity {
    private boolean shouldSummonArmy = true;
    
    // 雷电技能冷却相关
    private int lightningCooldown = 0;
    private static final int LIGHTNING_COOLDOWN_MAX = 20; // 1秒 = 20 tick

    @Unique
    private final SimpleInventory meleeInventory = new SimpleInventory(1);
    @Unique
    private final SimpleInventory rangeAttackInventory = new SimpleInventory(1);

    public DarkBoneLordEntity(EntityType<? extends ModAbstractSkeletonEntity> entityType, World world) {
        super(entityType, world);
        int hammerOrSword = this.getRandom().nextInt(2);
        meleeInventory.addStack(hammerOrSword == 0 ? new ItemStack(Tools.VIBRANIUM_SWORD) : new ItemStack(Tools.VIBRANIUM_HAMMER));
        rangeAttackInventory.addStack(new ItemStack(Items.BOW));
    }

    @Override
    protected RegistryKey<LootTable> getLootTableId() {
        return RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of(MOD_ID, "entity/dark_bone_lord"));
    }

    @Override
    protected int getXpToDrop() {
        return getXpForLevel(10); // 1000 XP
    }

    @Override
    protected void initEquipment(Random random, LocalDifficulty localDifficulty) {
        super.initEquipment(random, localDifficulty);
        this.equipStack(EquipmentSlot.MAINHAND, rangeAttackInventory.getStack(0));
        this.equipStack(EquipmentSlot.CHEST, new ItemStack(Armors.VIBRANIUM_CHEST_PLATE));
        this.equipStack(EquipmentSlot.FEET, new ItemStack(Armors.VIBRANIUM_BOOTS));
        this.equipStack(EquipmentSlot.LEGS, new ItemStack(Armors.VIBRANIUM_LEGGINGS));
        this.equipStack(EquipmentSlot.HEAD, new ItemStack(Armors.VIBRANIUM_HELMET));
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(2, new AvoidSunlightGoal(this));
        this.goalSelector.add(3, new EscapeSunlightGoal(this, 1.0));
        this.goalSelector.add(3, new FleeEntityGoal<>(this, WolfEntity.class, 6.0F, 1.0, 1.2));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 1.0));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8.0F));

        // ✅ DarkBoneLordTargetGoal 最高优先级 (1)，确保不会丢失目标
        this.targetSelector.add(1, new DarkBoneLordTargetGoal<>(this, PlayerEntity.class, false));
        // ✅ ActiveTargetGoal 次之
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, IronGolemEntity.class, true));
        // ✅ RevengeGoal 放最低优先级，避免覆盖主要目标
        this.targetSelector.add(3, new RevengeGoal(this));
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putBoolean("shouldSummonArmy", this.shouldSummonArmy);
        nbt.putInt("lightningCooldown", this.lightningCooldown);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (nbt.contains("shouldSummonArmy")) {
            this.shouldSummonArmy = nbt.getBoolean("shouldSummonArmy");
        }
        if (nbt.contains("lightningCooldown")) {
            this.lightningCooldown = nbt.getInt("lightningCooldown");
        }
    }

    public static boolean canSpawn(EntityType<FireElementalEntity> type, WorldAccess world, SpawnReason spawnReason, BlockPos pos, Random random) {
        return true;
    }

    @Override
    public void onDeath(DamageSource damageSource) {
        if (!this.isRemoved() && !this.dead) {
            Entity entity = damageSource.getAttacker();
            LivingEntity livingEntity = this.getPrimeAdversary();
            if (this.scoreAmount >= 0 && livingEntity != null) {
                livingEntity.updateKilledAdvancementCriterion(this, this.scoreAmount, damageSource);
            }

            if (this.isSleeping()) {
                this.wakeUp();
            }

            if (!this.getWorld().isClient && this.hasCustomName()) {
                OnServerInitialize.LOGGER.info("Named entity {} died: {}", this, this.getDamageTracker().getDeathMessage().getString());
            }

            this.dead = true;
            this.getDamageTracker().update();
            if (this.getWorld() instanceof ServerWorld serverWorld) {
                if (entity == null || entity.onKilledOther(serverWorld, this)) {
                    this.emitGameEvent(GameEvent.ENTITY_DIE);
                    this.drop(serverWorld, damageSource);
                    this.onKilledBy(livingEntity);
                }
                this.getWorld().sendEntityStatus(this, EntityStatuses.PLAY_DEATH_SOUND_OR_ADD_PROJECTILE_HIT_PARTICLES);
            }
            this.setPose(EntityPose.DYING);
        }
    }

    protected void drop(ServerWorld world, DamageSource damageSource) {
        this.dropInventory();
        this.dropXp(damageSource.getAttacker());
        
        this.dropStack(new ItemStack(Metal.DARK_BONE_LORD_ESSENCE, 1));
    }

    @Override
    public void onAttacking(Entity target) {
        super.onAttacking(target);
        if (target instanceof PlayerEntity player && this.getMainHandStack().isOf(Tools.VIBRANIUM_HAMMER)) {
            player.addStatusEffect(new StatusEffectInstance(SLOWNESS, 200, 3));
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 100, 1));
        }
    }

    /**
     * 召唤雷电技能
     */
    private void summonLightning(PlayerEntity target) {
        if (this.getWorld() instanceof ServerWorld serverWorld) {
            BlockPos targetPos = target.getBlockPos();
            LightningEntity lightning = EntityType.LIGHTNING_BOLT.create(serverWorld);
            if (lightning != null) {
                lightning.refreshPositionAfterTeleport(targetPos.getX(), targetPos.getY(), targetPos.getZ());
                serverWorld.spawnEntity(lightning);
            }
        }
    }

    /**
     * 更新雷电冷却
     */
    public void tickLightningCooldown() {
        if (this.lightningCooldown > 0) {
            this.lightningCooldown--;
        }
    }

    /**
     * 尝试对目标施放雷电
     */
    public void trySummonLightning(PlayerEntity target) {
        if (this.lightningCooldown <= 0 && target != null && !target.isRemoved() && target.isAlive()) {
            summonLightning(target);
            this.lightningCooldown = LIGHTNING_COOLDOWN_MAX;
        }
    }

    @Override
    public void tick() {
        super.tick();
        tickLightningCooldown();
    }

    // ======================== 内部类 DarkBoneLordTargetGoal ========================
    class DarkBoneLordTargetGoal<T extends LivingEntity> extends TrackTargetGoal {
        protected final Class<T> targetClass;
        protected final int reciprocalChance;
        @Nullable
        protected LivingEntity targetEntity;
        protected TargetPredicate targetPredicate;

        public DarkBoneLordTargetGoal(MobEntity mob, Class<T> targetClass, boolean checkVisibility) {
            this(mob, targetClass, 10, checkVisibility, false, null);
        }

        public DarkBoneLordTargetGoal(
                MobEntity mob,
                Class<T> targetClass,
                int reciprocalChance,
                boolean checkVisibility,
                boolean checkCanNavigate,
                @Nullable Predicate<LivingEntity> targetPredicate
        ) {
            super(mob, checkVisibility, checkCanNavigate);
            this.targetClass = targetClass;
            this.reciprocalChance = toGoalTicks(reciprocalChance);
            this.setControls(EnumSet.of(Goal.Control.TARGET));
            // ✅ 增大搜索距离，确保目标不会丢失
            this.targetPredicate = TargetPredicate.createAttackable()
                    .setBaseMaxDistance(64.0)
                    .setPredicate(targetPredicate);
        }

        @Override
        public boolean canStart() {
            // ✅ 如果已有目标且活着，直接继续
            if (this.mob.getTarget() != null && this.mob.getTarget().isAlive()) {
                this.targetEntity = this.mob.getTarget();
                return true;
            }
            this.findClosestTarget();
            return this.targetEntity != null;
        }

        // ✅ 确保目标不会丢失
        @Override
        public boolean shouldContinue() {
            LivingEntity target = this.mob.getTarget();
            if (target == null || !target.isAlive()) {
                return false;
            }
            // 如果目标在 64 格内，继续追击
            return this.mob.squaredDistanceTo(target) <= 64 * 64;
        }

        private ArrayList<BlockPos> getAvailablePositions(BlockPos mobPos) {
            ArrayList<BlockPos> optionalPos = new ArrayList<>();
            World world = this.mob.getEntityWorld();
            optionalPos.add(mobPos.east());
            optionalPos.add(mobPos.south());
            optionalPos.add(mobPos.west());
            optionalPos.add(mobPos.north());

            ArrayList<BlockPos> availablePos = new ArrayList<>();
            for (BlockPos pos : optionalPos) {
                for (int y = -2; y <= 2; y++) {
                    BlockPos checkPos = pos.add(0, y, 0);
                    boolean canStand = world.getBlockState(checkPos.down()).isFullCube(world, checkPos);
                    boolean enoughSpace = world.getBlockState(checkPos).isAir() && world.getBlockState(checkPos.up()).isAir();
                    if (canStand && enoughSpace) {
                        availablePos.add(checkPos);
                        break;
                    }
                }
            }
            return availablePos;
        }

        private void summonArmy(BlockPos mobPos) {
            ArrayList<BlockPos> positions = getAvailablePositions(mobPos);
            
            // 12个古尸
            int longdeadCount = 0;
            for (BlockPos pos : positions) {
                if (longdeadCount >= 12) break;
                if (this.mob.getWorld() instanceof ServerWorld serverWorld) {
                    LongDeadEntity army = LONG_DEAD.spawn(serverWorld, pos, SpawnReason.MOB_SUMMONED);
                    if (army != null) {
                        army.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 600, 1, false, false));
                        army.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 600, 1, false, false));
                        army.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 600, 1, false, true));
                        army.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 600, 1, false, false));
                        longdeadCount++;
                    }
                }
            }
            
            // 3个骷髅领主（骨王）
            int boneLordCount = 0;
            for (BlockPos pos : positions) {
                if (boneLordCount >= 3) break;
                BlockPos lordPos = mobPos.add(
                    (boneLordCount + 1) * 2,
                    0,
                    (boneLordCount + 1) * 2
                );
                if (this.mob.getWorld() instanceof ServerWorld serverWorld) {
                    BoneLordEntity lord = BONE_LORD.spawn(serverWorld, lordPos, SpawnReason.MOB_SUMMONED);
                    if (lord != null) {
                        lord.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 600, 2, false, false));
                        lord.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 600, 2, false, false));
                        lord.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 600, 2, false, true));
                        lord.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 600, 1, false, false));
                        boneLordCount++;
                    }
                }
            }
        }

        protected Box getSearchBox(double distance) {
            return this.mob.getBoundingBox().expand(distance, 4.0, distance);
        }

        protected void findClosestTarget() {
            if (this.mob.getAttacker() instanceof PlayerEntity attacker && attacker.isAlive()) {
                this.targetEntity = attacker;
                return;
            }

            double searchDistance = Math.max(this.getFollowRange(), 64.0);
            if (this.targetClass != PlayerEntity.class && this.targetClass != ServerPlayerEntity.class) {
                this.targetEntity = this.mob
                        .getWorld()
                        .getClosestEntity(
                                this.mob.getWorld().getEntitiesByClass(this.targetClass, this.getSearchBox(searchDistance), livingEntity -> true),
                                this.targetPredicate,
                                this.mob,
                                this.mob.getX(),
                                this.mob.getEyeY(),
                                this.mob.getZ()
                        );
            } else {
                this.targetEntity = this.mob.getWorld().getClosestPlayer(
                        this.targetPredicate,
                        this.mob,
                        this.mob.getX(),
                        this.mob.getEyeY(),
                        this.mob.getZ()
                );
            }
        }

        @Override
        public void start() {
            if (this.mob.getTarget() != null && this.mob.getTarget() != this.targetEntity) {
                return;
            }
            this.mob.setTarget(this.targetEntity);
            DarkBoneLordEntity mob = (DarkBoneLordEntity) this.mob;
            if (mob.shouldSummonArmy) {
                summonArmy(this.mob.getBlockPos());
                mob.shouldSummonArmy = false;
            }
            super.start();
        }

        @Override
        public void tick() {
            if (this.targetEntity == null) {
                this.findClosestTarget();
                if (this.targetEntity != null) {
                    this.mob.setTarget(this.targetEntity);
                }
                return;
            }

            ItemStack currentStack = this.mob.getStackInHand(Hand.MAIN_HAND);
            float distance = this.mob.distanceTo(this.targetEntity);

            if (this.targetEntity instanceof PlayerEntity player) {
                ((DarkBoneLordEntity) this.mob).trySummonLightning(player);
            }

            if (distance >= 8) {
                ItemStack rangeWeapon = rangeAttackInventory.getStack(0);
                if (!currentStack.isOf(rangeWeapon.getItem())) {
                    this.mob.setStackInHand(Hand.MAIN_HAND, rangeWeapon);
                }
            } else {
                ItemStack meleeWeapon = meleeInventory.getStack(0);
                if (!currentStack.isOf(meleeWeapon.getItem())) {
                    this.mob.setStackInHand(Hand.MAIN_HAND, meleeWeapon);
                }
            }
        }
    }
}