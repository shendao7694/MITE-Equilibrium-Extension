package com.equilibrium.entity;

public interface ITransformablePlayer {
    boolean isTransformed();
    void setTransformed(boolean transformed);
}