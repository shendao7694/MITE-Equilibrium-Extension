package com.equilibrium.mixin.structure_and_dimension.portal;

import com.equilibrium.block.ModBlocksRegistry;
import com.equilibrium.block.runic_obsidian.SilverRuneObsidian;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.NetherPortalBlock;
import net.minecraft.block.Portal;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.TeleportTarget;
import net.minecraft.world.World;
import net.minecraft.world.border.WorldBorder;
import net.minecraft.world.dimension.DimensionType;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.*;
import java.util.stream.Collectors;

import static com.equilibrium.OnServerInitialize.MOD_ID;

@Mixin(NetherPortalBlock.class)
public abstract class NetherPortalBlockMixin extends Block implements Portal {

    @Shadow
    @Nullable
    protected abstract TeleportTarget getOrCreateExitPortalTarget(ServerWorld world, Entity entity, BlockPos pos, BlockPos scaledPos, boolean inNether, WorldBorder worldBorder);

    @Shadow
    @Final
    private static Logger LOGGER;

    public NetherPortalBlockMixin(Settings settings) {
        super(settings);
    }

    @Unique
    private static RegistryKey<World> getOverworldKey() {
        return World.OVERWORLD;
    }

    @Unique
    private static RegistryKey<World> getNetherKey() {
        return World.NETHER;
    }

    @Unique
    private static RegistryKey<World> getUnderworldKey() {
        return RegistryKey.of(RegistryKeys.WORLD, Identifier.of(MOD_ID, "underworld"));
    }

    @Unique
    private static final String TRANSPORT_TARGET1 = "You will transport to overworld";
    @Unique
    private static final String TRANSPORT_TARGET2 = "You will transport to underworld";
    @Unique
    private static final String TRANSPORT_TARGET3 = "You will transport to nether";
    @Unique
    private static final String TRANSPORT_TARGET_RUNE = "You will transport via rune portal";

    @Unique
    private static String getTeleportWorld(World world, Entity entity, boolean hasRunePortal) {
        if (hasRunePortal) {
            return TRANSPORT_TARGET_RUNE;
        }

        RegistryKey<World> registryKey = world.getRegistryKey();
        RegistryKey<World> teleport;

        if (registryKey == null) {
            return "Not an illegal transportation";
        } else {
            boolean atBottom = Math.abs(entity.getY() - world.getBottomY()) < 5;
            boolean buffer = Math.abs(entity.getY() - world.getBottomY()) >= 5 && Math.abs(entity.getY() - world.getBottomY()) < 8;

            if (world.getRegistryKey() == getOverworldKey() && atBottom) {
                teleport = getUnderworldKey();
            } else if (world.getRegistryKey() == getOverworldKey() && !atBottom && !buffer) {
                teleport = getOverworldKey();
            } else if (world.getRegistryKey() == getUnderworldKey() && !atBottom && !buffer) {
                teleport = getOverworldKey();
            } else if (world.getRegistryKey() == getUnderworldKey() && atBottom) {
                teleport = getNetherKey();
            } else if (world.getRegistryKey() == getNetherKey()) {
                teleport = getUnderworldKey();
            } else {
                teleport = world.getRegistryKey();
            }

            String worldType;
            if (teleport == getUnderworldKey()) {
                worldType = TRANSPORT_TARGET2;
            } else if (teleport == getOverworldKey()) {
                worldType = TRANSPORT_TARGET1;
            } else if (teleport == getNetherKey()) {
                worldType = TRANSPORT_TARGET3;
            } else {
                worldType = "Not an illegal transportation";
            }
            return worldType;
        }
    }


    @Unique
    private static class RuneInfo {
        public final BlockPos pos;
        public final SilverRuneObsidian.Variant variant;

        public RuneInfo(BlockPos pos, SilverRuneObsidian.Variant variant) {
            this.pos = pos;
            this.variant = variant;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            RuneInfo runeInfo = (RuneInfo) o;
            return Objects.equals(pos, runeInfo.pos) && variant == runeInfo.variant;
        }

        @Override
        public int hashCode() {
            return Objects.hash(pos, variant);
        }
    }

    @Unique
    private List<RuneInfo> findNearbyRunes(World world, BlockPos portalPos, int searchRadius) {
        List<RuneInfo> runes = new ArrayList<>();

        for (int dx = -searchRadius; dx <= searchRadius; dx++) {
            for (int dy = -searchRadius; dy <= searchRadius; dy++) {
                for (int dz = -searchRadius; dz <= searchRadius; dz++) {
                    BlockPos checkPos = portalPos.add(dx, dy, dz);
                    BlockState state = world.getBlockState(checkPos);

                    if (state.getBlock() == ModBlocksRegistry.SILVER_RUNE_OBSIDIAN) {
                        SilverRuneObsidian.Variant variant = state.get(SilverRuneObsidian.VARIANT);
                        runes.add(new RuneInfo(checkPos, variant));
                    }
                }
            }
        }

        runes.sort(Comparator.comparingDouble(r -> r.pos.getSquaredDistance(portalPos)));
        return runes.stream().limit(4).collect(Collectors.toList());
    }

    @Unique
    private boolean hasRunePortal(World world, BlockPos portalPos) {
        List<RuneInfo> runes = findNearbyRunes(world, portalPos, 5);
        return runes.size() >= 4;
    }

    @Unique
    private long generateRuneHash(List<RuneInfo> runes, BlockPos portalPos) {
        runes.sort(Comparator.comparing(r -> r.pos.asLong()));

        StringBuilder hashBuilder = new StringBuilder();
        for (RuneInfo rune : runes) {
            hashBuilder.append(rune.pos.getX()).append(",")
                    .append(rune.pos.getY()).append(",")
                    .append(rune.pos.getZ()).append(",")
                    .append(rune.variant.name()).append(";");
        }
        hashBuilder.append(portalPos.getX()).append(",")
                .append(portalPos.getY()).append(",")
                .append(portalPos.getZ());

        return hashBuilder.toString().hashCode() & 0x7FFFFFFF;
    }

    @Unique
    private BlockPos getRuneTeleportPosition(ServerWorld targetWorld, long seed) {
        Random random = new Random(seed);
        WorldBorder border = targetWorld.getWorldBorder();
        int borderSize = (int) border.getSize() / 2;

        int range = Math.min(10000, borderSize - 10);
        if (range < 7000) range = 7000;

        for (int attempt = 0; attempt < 30; attempt++) {
            int x = random.nextInt(range * 2) - range;
            int z = random.nextInt(range * 2) - range;

            int chunkX = x >> 4;
            int chunkZ = z >> 4;
            targetWorld.getChunk(chunkX, chunkZ);

            int y = targetWorld.getTopY(Heightmap.Type.WORLD_SURFACE, x, z);
            if (y <= targetWorld.getBottomY() + 1) {
                y = targetWorld.getTopY(Heightmap.Type.MOTION_BLOCKING, x, z);
            }
            if (y <= targetWorld.getBottomY() + 1) {
                y = targetWorld.getTopY(Heightmap.Type.OCEAN_FLOOR, x, z);
            }

            if (y <= targetWorld.getBottomY() + 1 || y >= targetWorld.getTopY()) {
                continue;
            }

            BlockPos pos = new BlockPos(x, y, z);
            BlockState below = targetWorld.getBlockState(pos.down());
            BlockState ground = targetWorld.getBlockState(pos);
            BlockState above = targetWorld.getBlockState(pos.up());
            BlockState above2 = targetWorld.getBlockState(pos.up(2));

            if (below.isSideSolidFullSquare(targetWorld, pos.down(), Direction.UP) && 
                ground.isAir() && 
                above.isAir() && 
                above2.isAir() &&
                ground.getFluidState().isEmpty() &&
                above.getFluidState().isEmpty()) {
                return pos;
            }
        }

        BlockPos spawnPos = targetWorld.getSpawnPos();
        int y = targetWorld.getTopY(Heightmap.Type.WORLD_SURFACE, spawnPos.getX(), spawnPos.getZ());
        if (y <= targetWorld.getBottomY() + 1) {
            y = targetWorld.getBottomY() + 5;
        }
        for (int i = y; i < y + 5; i++) {
            BlockPos checkPos = new BlockPos(spawnPos.getX(), i, spawnPos.getZ());
            if (targetWorld.getBlockState(checkPos).isAir() && 
                targetWorld.getBlockState(checkPos.up()).isAir()) {
                return checkPos;
            }
        }
        return new BlockPos(spawnPos.getX(), y + 1, spawnPos.getZ());
    }

    @Inject(method = "onEntityCollision", at = @At(value = "HEAD"), cancellable = true)
    protected void onEntityCollision(BlockState state, World world, BlockPos pos, Entity entity, CallbackInfo ci) {
        ci.cancel();

        if (world.isClient) {
            return;
        }

        if (entity.canUsePortals(true)) {
            boolean hasRunePortal = hasRunePortal(world, pos);

            entity.tryUsePortal(this, pos);
            if (entity instanceof PlayerEntity player) {
                String teleport = getTeleportWorld(world, entity, hasRunePortal);
                if (Objects.equals(teleport, TRANSPORT_TARGET1)) {
                    player.sendMessage(Text.of(Text.translatable("teleport.overworld").formatted(Formatting.YELLOW)), true);
                } else if (Objects.equals(teleport, TRANSPORT_TARGET2)) {
                    player.sendMessage(Text.of(Text.translatable("teleport.underworld").formatted(Formatting.YELLOW)), true);
                } else if (Objects.equals(teleport, TRANSPORT_TARGET3)) {
                    player.sendMessage(Text.of(Text.translatable("teleport.nether").formatted(Formatting.YELLOW)), true);
                } else if (Objects.equals(teleport, TRANSPORT_TARGET_RUNE)) {
                    player.sendMessage(Text.of(Text.translatable("teleport.rune_portal").formatted(Formatting.LIGHT_PURPLE)), true);
                } else {
                    player.sendMessage(Text.of("You shouldn't receive this message, you might teleport to an unsupported dimension"), true);
                }
            }
        }
    }

    @Unique
    public TeleportTarget toSpawn(ServerWorld world, Entity entity) {
        RegistryKey<World> registryKey = world.getRegistryKey();
        ServerWorld serverWorld = world.getServer().getWorld(registryKey);
        if (serverWorld == null) {
            return null;
        } else {
            BlockPos blockPos = serverWorld.getSpawnPos();
            float f = entity.getYaw();
            if (entity instanceof ServerPlayerEntity serverPlayerEntity) {
                return serverPlayerEntity.getRespawnTarget(false, TeleportTarget.NO_OP);
            }
            Vec3d vec3d = entity.getWorldSpawnPos(serverWorld, blockPos).toBottomCenterPos();
            return new TeleportTarget(
                    serverWorld,
                    vec3d,
                    entity.getVelocity(),
                    f,
                    entity.getPitch(),
                    TeleportTarget.SEND_TRAVEL_THROUGH_PORTAL_PACKET.then(TeleportTarget.ADD_PORTAL_CHUNK_TICKET)
            );
        }
    }

    @Inject(method = "createTeleportTarget", at = @At(value = "HEAD"), cancellable = true)
    public void createTeleportTarget(ServerWorld world, Entity entity, BlockPos pos, CallbackInfoReturnable<TeleportTarget> cir) {
        cir.cancel();

        RegistryKey<World> registryKey = world.getRegistryKey();
        RegistryKey<World> teleport;

        if (registryKey == null) {
            cir.setReturnValue(null);
            return;
        }

        ServerWorld serverWorld;
        boolean inNether = world.getRegistryKey() == getNetherKey();
        WorldBorder worldBorder = world.getWorldBorder();
        double d = DimensionType.getCoordinateScaleFactor(world.getDimension(), world.getDimension());
        BlockPos blockPos = worldBorder.clamp(entity.getX() * d, entity.getY(), entity.getZ() * d);

        List<RuneInfo> runes = findNearbyRunes(world, pos, 5);
        boolean hasRunePortal = runes.size() >= 4;

        if (hasRunePortal) {
            long seed = generateRuneHash(runes, pos);
            RegistryKey<World> targetDimension = world.getRegistryKey();
            serverWorld = world.getServer().getWorld(targetDimension);

            if (serverWorld == null) {
                serverWorld = world;
            }

            BlockPos targetPos = getRuneTeleportPosition(serverWorld, seed);

            if (entity instanceof ServerPlayerEntity player) {
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 100, 255, false, false, false));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 120, 255, false, false, false));
            }

            Vec3d teleportPos = new Vec3d(
                    targetPos.getX() + 0.5,
                    targetPos.getY() + 0.1,
                    targetPos.getZ() + 0.5
            );

            cir.setReturnValue(new TeleportTarget(
                    serverWorld,
                    teleportPos,
                    entity.getVelocity(),
                    entity.getYaw(),
                    entity.getPitch(),
                    TeleportTarget.SEND_TRAVEL_THROUGH_PORTAL_PACKET.then(TeleportTarget.ADD_PORTAL_CHUNK_TICKET)
            ));
            return;
        }

        boolean atBottom = Math.abs(entity.getY() - world.getBottomY()) < 5;
        boolean buffer = Math.abs(entity.getY() - world.getBottomY()) >= 5 && Math.abs(entity.getY() - world.getBottomY()) < 8;

        if (world.getRegistryKey() == getOverworldKey() && atBottom) {
            teleport = getUnderworldKey();
        } else if (world.getRegistryKey() == getOverworldKey() && !atBottom && !buffer) {
            teleport = getOverworldKey();
        } else if (world.getRegistryKey() == getUnderworldKey() && !atBottom && !buffer) {
            teleport = getOverworldKey();
        } else if (world.getRegistryKey() == getUnderworldKey() && atBottom) {
            teleport = getNetherKey();
        } else if (world.getRegistryKey() == getNetherKey()) {
            teleport = getUnderworldKey();
        } else {
            teleport = world.getRegistryKey();
        }

        serverWorld = world.getServer().getWorld(teleport);
        cir.setReturnValue(this.getOrCreateExitPortalTarget(serverWorld, entity, pos, blockPos, inNether, worldBorder));
    }
}