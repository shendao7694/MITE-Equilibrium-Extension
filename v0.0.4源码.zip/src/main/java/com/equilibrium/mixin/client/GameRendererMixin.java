package com.equilibrium.mixin.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.PostEffectProcessor;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {

    @Shadow
    private PostEffectProcessor postProcessor;

    @Shadow
    public abstract void loadPostProcessor(Identifier id);

    @Unique
    private static final Identifier INVERT_SHADER = Identifier.of("minecraft", "shaders/post/invert.json");

    @Unique
    private boolean lastFrozenState = false;

    @Inject(method = "render", at = @At(value = "HEAD"))
    private void onRender(CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) return;

        boolean isFrozen = client.world.getTickManager().isFrozen();

        if (isFrozen && !lastFrozenState) {
            try {
                loadPostProcessor(INVERT_SHADER);
                lastFrozenState = true;
            } catch (Exception e) {
                
            }
        } else if (!isFrozen && lastFrozenState) {
            try {
                if (postProcessor != null) {
                    postProcessor.close();
                    postProcessor = null;
                }
                lastFrozenState = false;
            } catch (Exception e) {
                
            }
        }
    }
}