package com.equilibrium.event;

import com.equilibrium.entity.ModEntities;
import com.equilibrium.entity.mob.DarkBoneLordEntity;
import com.equilibrium.entity.mob.EndlessSkeletonEntity;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

public class BlazeSpawnerBreakEvent {

    public static void register() {
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (world.isClient) {
                return;
            }

            if (state.getBlock() == Blocks.SPAWNER && blockEntity instanceof MobSpawnerBlockEntity spawner) {
                if (spawner.getLogic().getRenderedEntity(world, pos).getType() == EntityType.BLAZE) {
                    spawnEndlessSkeleton((ServerWorld) world, pos, (ServerPlayerEntity) player);
                }
                if (spawner.getLogic().getRenderedEntity(world, pos).getType() == ModEntities.LONG_DEAD) {
                    spawnDarkBoneLord((ServerWorld) world, pos, (ServerPlayerEntity) player);
                }
            }
        });
    }

    private static void spawnEndlessSkeleton(ServerWorld world, BlockPos pos, ServerPlayerEntity player) {
        EndlessSkeletonEntity endlessSkeleton = ModEntities.ENDLESS_SKELETON.spawn(
            world,
            pos,
            SpawnReason.TRIGGERED
        );

        if (endlessSkeleton != null) {
            player.sendMessage(Text.translatable("event.miteequilibrium.endless_skeleton.spawn").formatted(Formatting.DARK_RED), false);
        }
    }

    private static void spawnDarkBoneLord(ServerWorld world, BlockPos pos, ServerPlayerEntity player) {
        DarkBoneLordEntity darkBoneLord = ModEntities.DARK_BONE_LORD.spawn(
            world,
            pos,
            SpawnReason.TRIGGERED
        );

        if (darkBoneLord != null) {
            player.sendMessage(Text.translatable("event.miteequilibrium.dark_bone_lord.spawn").formatted(Formatting.RED), false);
        }
    }
}